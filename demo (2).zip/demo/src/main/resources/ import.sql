insert into aluno (id, nome, media_notas) values (1, 'Ana', 10);
insert into aluno (id, nome, media_notas) values (2, 'Maria', 3);
insert into aluno (id, nome, media_notas) values (3, 'Ricardo', 7);

insert into usuario (id, login, senha) values (1, 'admin', 'admin')