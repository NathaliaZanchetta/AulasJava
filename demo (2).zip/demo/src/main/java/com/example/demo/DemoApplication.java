package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;

import br.usjt.hellospringboot.model.Aluno;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@PostMapping
	public String salvar(Aluno aluno) {
		Object alunosRepo;
		((Object) alunosRepo).save(aluno);
		return "redirect:/alunos";
	}
}
