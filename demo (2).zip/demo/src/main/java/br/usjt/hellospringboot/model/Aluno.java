package br.usjt.hellospringboot.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Aluno implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String nome;
	private Double nota1;
	private Double nota2;
	private Double mediaFinal;
	// getters/setters
	
	public double getNota2() {
		// TODO Auto-generated method stub
		return 0;
	}
	public double getNota1() {
		// TODO Auto-generated method stub
		return 0;
	}
	public void setMediaFinal(double calculaMedia) {
		// TODO Auto-generated method stub
		
	}
}
